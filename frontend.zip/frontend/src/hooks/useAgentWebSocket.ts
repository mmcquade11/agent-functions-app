import { useEffect, useRef, useState } from "react";
import { useAuth0 } from "@auth0/auth0-react";

type StreamMessage = {
  phase: "reasoning" | "claude" | "done";
  type: "text" | "tool_use" | "tool_result" | "code" | "start" | "done";
  content?: string;
  tool?: string;
  input?: any;
  result?: any;
};

export function useAgentWebSocket(prompt: string | null) {
  const { getAccessTokenSilently } = useAuth0();
  const [messages, setMessages] = useState<StreamMessage[]>([]);
  const [isStreaming, setIsStreaming] = useState(false);
  const socketRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    if (!prompt) return;

    let ws: WebSocket;

    (async () => {
      const token = await getAccessTokenSilently();
      ws = new WebSocket(`ws://localhost:8000/ws/execute-agent?token=${token}`);
      socketRef.current = ws;
      setMessages([]);
      setIsStreaming(true);

      ws.onopen = () => {
        ws.send(JSON.stringify({ prompt }));
      };

      ws.onmessage = (event) => {
        const data: StreamMessage = JSON.parse(event.data);
        setMessages((prev) => [...prev, data]);
        if (data.type === "done") {
          setIsStreaming(false);
        }
      };

      ws.onerror = (err) => {
        console.error("WebSocket error:", err);
        setIsStreaming(false);
      };

      ws.onclose = () => {
        setIsStreaming(false);
      };
    })();

    return () => {
      ws?.close();
    };
  }, [prompt]);

  return { messages, isStreaming };
}
